My Open Core config for MSI H110M-PRO-VD motherboard.

For macOS Mojave 10.15.7 - Big Sur 11.0.1
Open Core 0.6.3

Original guide: https://dortania.github.io/OpenCore-Install-Guide/

Dont' forget to add serial to config.plist with GenSMBIOS (Software folder).
https://dortania.github.io/OpenCore-Post-Install/universal/iservices.html#generate-a-new-serial
https://github.com/corpnewt/GenSMBIOS
